console.log("Good Luck Noob")
